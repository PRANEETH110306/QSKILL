CREATE TABLE IF NOT EXISTS users (

    id INTEGER PRIMARY KEY AUTOINCREMENT,

    username TEXT NOT NULL,

    email TEXT UNIQUE NOT NULL,

    password TEXT NOT NULL,

    role TEXT NOT NULL

);



CREATE TABLE IF NOT EXISTS events (

    id INTEGER PRIMARY KEY AUTOINCREMENT,

    title TEXT NOT NULL,

    description TEXT,

    date TEXT NOT NULL,

    time TEXT NOT NULL,

    location TEXT NOT NULL,

    capacity INTEGER NOT NULL,

    status TEXT DEFAULT 'Pending',

    created_by INTEGER,

    FOREIGN KEY(created_by) REFERENCES users(id)

);



CREATE TABLE IF NOT EXISTS registrations (

    id INTEGER PRIMARY KEY AUTOINCREMENT,

    user_id INTEGER,

    event_id INTEGER,

    registered_on TEXT,

    FOREIGN KEY(user_id) REFERENCES users(id),

    FOREIGN KEY(event_id) REFERENCES events(id)

);  