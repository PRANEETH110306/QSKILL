from flask import Flask, render_template, request, redirect, session
import sqlite3
from datetime import datetime

app = Flask(__name__)

app.secret_key = "event_management_secret"

DB = "database.db"


def get_db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():

    conn = get_db()

    with open("sql/schema.sql", "r") as f:
        conn.executescript(f.read())

    admin = conn.execute(
        "SELECT * FROM users WHERE email=?",
        ("admin@gmail.com",)
    ).fetchone()

    if not admin:
        conn.execute(
            """
            INSERT INTO users(username,email,password,role)
            VALUES(?,?,?,?)
            """,
            (
                "Admin",
                "admin@gmail.com",
                "admin123",
                "admin"
            )
        )

    user = conn.execute(
        "SELECT * FROM users WHERE email=?",
        ("user@gmail.com",)
    ).fetchone()

    if not user:
        conn.execute(
            """
            INSERT INTO users(username,email,password,role)
            VALUES(?,?,?,?)
            """,
            (
                "User",
                "user@gmail.com",
                "user123",
                "user"
            )
        )

    conn.commit()
    conn.close()


init_db()


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/register", methods=["GET", "POST"])
def register():

    if request.method == "POST":

        username = request.form["username"]
        email = request.form["email"]
        password = request.form["password"]

        conn = get_db()

        existing = conn.execute(
            """
            SELECT *
            FROM users
            WHERE email=?
            """,
            (email,)
        ).fetchone()

        if existing:
            conn.close()
            return "Email already exists!"

        conn.execute(
            """
            INSERT INTO users
            (username,email,password,role)
            VALUES(?,?,?,?)
            """,
            (
                username,
                email,
                password,
                "user"
            )
        )

        conn.commit()
        conn.close()

        return redirect("/login")

    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():

    if request.method == "POST":

        email = request.form["email"]
        password = request.form["password"]

        conn = get_db()

        user = conn.execute(
            """
            SELECT *
            FROM users
            WHERE email=? AND password=?
            """,
            (
                email,
                password
            )
        ).fetchone()

        conn.close()

        if user:

            session["user_id"] = user["id"]
            session["username"] = user["username"]
            session["role"] = user["role"]

            if user["role"] == "admin":
                return redirect("/admin")

            return redirect("/events")

        return "Invalid Email or Password"

    return render_template("login.html")


@app.route("/logout")
def logout():

    session.clear()

    return redirect("/")

@app.route("/events", methods=["GET", "POST"])
def events():

    if "user_id" not in session:
        return redirect("/login")

    conn = get_db()

    if request.method == "POST":

        title = request.form["title"]
        description = request.form["description"]
        date = request.form["date"]
        time = request.form["time"]
        location = request.form["location"]
        capacity = request.form["capacity"]

        conn.execute("""
            INSERT INTO events
            (title,description,date,time,location,capacity,status,created_by)
            VALUES(?,?,?,?,?,?,?,?)
        """,
        (
            title,
            description,
            date,
            time,
            location,
            capacity,
            "Pending",
            session["user_id"]
        ))

        conn.commit()

    date = request.args.get("date")
    location = request.args.get("location")

    query = """
        SELECT events.*,
               users.username
        FROM events
        JOIN users
        ON events.created_by = users.id
    """

    conditions = []
    params = []

    if session["role"] != "admin":
        conditions.append("status='Approved'")

    if date:
        conditions.append("date=?")
        params.append(date)

    if location:
        conditions.append("location LIKE ?")
        params.append(f"%{location}%")

    if conditions:
        query += " WHERE " + " AND ".join(conditions)

    query += " ORDER BY date"

    events = conn.execute(
        query,
        params
    ).fetchall()

    conn.close()

    return render_template(
        "events.html",
        events=events
    )


@app.route("/admin")
def admin():

    if "user_id" not in session:
        return redirect("/login")

    if session["role"] != "admin":
        return redirect("/events")

    conn = get_db()

    events = conn.execute("""
        SELECT events.*,
               users.username
        FROM events
        JOIN users
        ON events.created_by = users.id
        ORDER BY date
    """).fetchall()

    conn.close()

    return render_template(
        "admin.html",
        events=events
    )


@app.route("/approve/<int:id>")
def approve(id):

    if session.get("role") != "admin":
        return redirect("/login")

    conn = get_db()

    conn.execute(
        """
        UPDATE events
        SET status='Approved'
        WHERE id=?
        """,
        (id,)
    )

    conn.commit()
    conn.close()

    return redirect("/admin")


@app.route("/reject/<int:id>")
def reject(id):

    if session.get("role") != "admin":
        return redirect("/login")

    conn = get_db()

    conn.execute(
        """
        UPDATE events
        SET status='Rejected'
        WHERE id=?
        """,
        (id,)
    )

    conn.commit()
    conn.close()

    return redirect("/admin")

@app.route("/register_event/<int:event_id>")
def register_event(event_id):

    if "user_id" not in session:
        return redirect("/login")

    conn = get_db()

    existing = conn.execute(
        """
        SELECT *
        FROM registrations
        WHERE user_id=? AND event_id=?
        """,
        (
            session["user_id"],
            event_id
        )
    ).fetchone()

    if existing:
        conn.close()
        return "Already Registered!"

    event = conn.execute(
        """
        SELECT *
        FROM events
        WHERE id=?
        """,
        (event_id,)
    ).fetchone()

    registered = conn.execute(
        """
        SELECT COUNT(*)
        FROM registrations
        WHERE event_id=?
        """,
        (event_id,)
    ).fetchone()[0]

    if registered >= event["capacity"]:
        conn.close()
        return "Event Capacity Full!"

    conn.execute(
        """
        INSERT INTO registrations
        (user_id,event_id,registered_on)
        VALUES(?,?,?)
        """,
        (
            session["user_id"],
            event_id,
            datetime.now().strftime("%d-%m-%Y")
        )
    )

    conn.commit()
    conn.close()

    return redirect("/registrations")


@app.route("/registrations")
def registrations():

    if "user_id" not in session:
        return redirect("/login")

    conn = get_db()

    registrations = conn.execute("""
        SELECT
            registrations.id,
            registrations.registered_on,
            events.title,
            events.date,
            events.time,
            events.location
        FROM registrations
        JOIN events
        ON registrations.event_id = events.id
        WHERE registrations.user_id=?
    """,
    (session["user_id"],)
    ).fetchall()

    conn.close()

    return render_template(
        "registrations.html",
        registrations=registrations
    )


@app.route("/cancel_registration/<int:id>")
def cancel_registration(id):

    if "user_id" not in session:
        return redirect("/login")

    conn = get_db()

    conn.execute(
        """
        DELETE FROM registrations
        WHERE id=?
        """,
        (id,)
    )

    conn.commit()
    conn.close()

    return redirect("/registrations")


if __name__ == "__main__":
    app.run(debug=True)