from flask import Flask, render_template
import sqlite3
import os
from flask import Flask, render_template, request, redirect
from datetime import datetime

app = Flask(__name__)

DB = "database.db"


def get_db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    if not os.path.exists(DB):
        conn = get_db()

        with open("sql/schema.sql", "r") as f:
            conn.executescript(f.read())

        jobs = [
            ("Python Developer", "Google", "Bangalore", "12 LPA", "Python + Flask Developer"),
            ("Frontend Developer", "Microsoft", "Hyderabad", "10 LPA", "HTML CSS JavaScript"),
            ("Cyber Security Analyst", "IBM", "Pune", "8 LPA", "SOC Analyst"),
            ("Data Analyst", "Amazon", "Chennai", "9 LPA", "SQL + Power BI")
        ]

        conn.executemany(
            """
            INSERT INTO jobs(title, company, location, salary, description)
            VALUES(?,?,?,?,?)
            """,
            jobs
        )

        conn.commit()
        conn.close()


init_db()


@app.route("/")
def home():
    return render_template("index.html")

@app.route("/jobs")
def jobs():
    conn = get_db()
    jobs = conn.execute("SELECT * FROM jobs").fetchall()
    conn.close()

    return render_template("jobs.html", jobs=jobs)

@app.route("/apply/<int:job_id>", methods=["GET", "POST"])
def apply(job_id):
    conn = get_db()

    job = conn.execute(
        "SELECT * FROM jobs WHERE id=?",
        (job_id,)
    ).fetchone()

    if request.method == "POST":
        name = request.form["name"]
        email = request.form["email"]

        conn.execute(
            """
            INSERT INTO applications(name, email, job_id, applied_date)
            VALUES (?,?,?,?)
            """,
            (
                name,
                email,
                job_id,
                datetime.now().strftime("%d-%m-%Y")
            )
        )

        conn.commit()
        conn.close()

        return redirect("/applications")

    conn.close()
    return render_template("apply.html", job=job)

@app.route("/applications")
def applications():
    conn = get_db()

    applications = conn.execute("""
        SELECT applications.id,
               applications.name,
               applications.email,
               applications.applied_date,
               jobs.title,
               jobs.company
        FROM applications
        JOIN jobs
        ON applications.job_id = jobs.id
    """).fetchall()

    conn.close()

    return render_template(
        "applications.html",
        applications=applications
    )

@app.route("/delete/<int:id>")
def delete(id):
    conn = get_db()

    conn.execute(
        "DELETE FROM applications WHERE id=?",
        (id,)
    )

    conn.commit()
    conn.close()

    return redirect("/applications")

@app.route("/search", methods=["GET", "POST"])
def search():
    jobs = []

    if request.method == "POST":
        keyword = request.form["keyword"]

        conn = get_db()

        jobs = conn.execute("""
            SELECT * FROM jobs
            WHERE title LIKE ?
               OR company LIKE ?
               OR location LIKE ?
        """,
        (
            f"%{keyword}%",
            f"%{keyword}%",
            f"%{keyword}%"
        )).fetchall()

        conn.close()

    return render_template("search.html", jobs=jobs, request=request)

if __name__ == "__main__":
    app.run(debug=True)