const btn = document.getElementById("themeBtn");

if(btn){

const saved = localStorage.getItem("theme");

if(saved==="dark"){

document.body.classList.add("dark");
btn.innerHTML="☀️";

}

btn.onclick=()=>{

document.body.classList.toggle("dark");

if(document.body.classList.contains("dark")){

localStorage.setItem("theme","dark");
btn.innerHTML="☀️";

}else{

localStorage.setItem("theme","light");
btn.innerHTML="🌙";

}

};

}